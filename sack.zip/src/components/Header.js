import React from "react";

const Header = () => {
  return (
    <div>
      <h2>My Header</h2>
    </div>
  );
};

export default Header;
